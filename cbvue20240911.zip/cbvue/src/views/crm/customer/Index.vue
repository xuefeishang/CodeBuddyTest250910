<template>
  <div class="customer-container">
    <h2>客户管理</h2>
    <p>这里是客户管理页面</p>
  </div>
</template>

<script setup lang="ts">
// 客户管理页面逻辑
</script>

<style scoped lang="scss">
.customer-container {
  padding: 20px;
}
</style>