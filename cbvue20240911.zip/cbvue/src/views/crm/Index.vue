<template>
  <div class="crm-container">
    <router-view />
  </div>
</template>

<script setup lang="ts">
// CRM模块入口
</script>

<style scoped lang="scss">
.crm-container {
  padding: 20px;
}
</style>