<template>
  <div class="system-container">
    <router-view />
  </div>
</template>

<script setup lang="ts">
// 系统管理模块入口
</script>

<style scoped lang="scss">
.system-container {
  padding: 20px;
}
</style>