<template>
  <div class="role-container">
    <h2>角色管理</h2>
    <p>这里是角色管理页面</p>
  </div>
</template>

<script setup lang="ts">
// 角色管理页面逻辑
</script>

<style scoped lang="scss">
.role-container {
  padding: 20px;
}
</style>