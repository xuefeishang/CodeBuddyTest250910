<template>
  <div class="user-container">
    <h2>用户管理</h2>
    <p>这里是用户管理页面</p>
  </div>
</template>

<script setup lang="ts">
// 用户管理页面逻辑
</script>

<style scoped lang="scss">
.user-container {
  padding: 20px;
}
</style>