<template>
  <div class="task-container">
    <h2>任务管理</h2>
    <p>这里是任务管理页面</p>
  </div>
</template>

<script setup lang="ts">
// 任务管理页面逻辑
</script>

<style scoped lang="scss">
.task-container {
  padding: 20px;
}
</style>