<template>
  <div class="project-list-container">
    <h2>项目列表</h2>
    <p>这里是项目列表页面</p>
  </div>
</template>

<script setup lang="ts">
// 项目列表页面逻辑
</script>

<style scoped lang="scss">
.project-list-container {
  padding: 20px;
}
</style>