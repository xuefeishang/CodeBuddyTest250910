<template>
  <div class="project-container">
    <router-view />
  </div>
</template>

<script setup lang="ts">
// 项目管理模块入口
</script>

<style scoped lang="scss">
.project-container {
  padding: 20px;
}
</style>