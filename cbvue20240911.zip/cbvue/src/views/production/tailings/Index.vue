<template>
  <div>尾矿管理页面</div>
</template>