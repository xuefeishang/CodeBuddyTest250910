<template>
  <div>选矿管理页面</div>
</template>