<template>
  <div>采矿管理页面</div>
</template>