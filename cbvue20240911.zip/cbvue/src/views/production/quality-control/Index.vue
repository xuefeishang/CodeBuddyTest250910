<template>
  <div>质检管理页面</div>
</template>