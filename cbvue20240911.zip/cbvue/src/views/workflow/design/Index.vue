<template>
  <div class="design-container">
    <h2>流程设计</h2>
    <p>这里是流程设计页面</p>
  </div>
</template>

<script setup lang="ts">
// 流程设计页面逻辑
</script>

<style scoped lang="scss">
.design-container {
  padding: 20px;
}
</style>