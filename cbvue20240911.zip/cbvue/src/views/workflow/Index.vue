<template>
  <div class="workflow-container">
    <router-view />
  </div>
</template>

<script setup lang="ts">
// 工作流模块入口
</script>

<style scoped lang="scss">
.workflow-container {
  padding: 20px;
}
</style>