<template>
  <div class="approval-container">
    <h2>审批中心</h2>
    <p>这里是审批中心页面</p>
  </div>
</template>

<script setup lang="ts">
// 审批中心页面逻辑
</script>

<style scoped lang="scss">
.approval-container {
  padding: 20px;
}
</style>